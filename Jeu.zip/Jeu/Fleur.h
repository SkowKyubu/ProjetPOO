#ifndef DEF_FLEUR
#define DEF_FLEUR
#include "CImg.h"
#include <iostream>
#include <string>
#include "Plante.h"

using namespace std;
using namespace cimg_library;


class Fleur : public Plante{
public:
    Fleur(int);
    ~Fleur();
};
#endif
