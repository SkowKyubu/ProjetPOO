#ifndef DEF_CHAMPS
#define DEF_CHAMPS
#include <iostream>
#include <vector>
#include <ctime>
#include "CImg.h"
#include "Jardin.h"
#include <cstdlib>
#include "Jardinier.h"

using namespace std;
using namespace cimg_library;

class Champs{
private:
    int nombre_jardinier;
    int nombre_grain;

public:
    CImg<unsigned char> image;
    Jardin garden;
    vector<vector<Jardinier>> matrix_jardinier;
    void draw_Jardinier();
    int get_nombre_jardinier();
    int get_nombre_grain();
    void set_nombre_jardinier(int);
    void set_nombre_grain(int);
    void placer_jardinier(Jardinier&,int,int);
    void deplacer_jardinier(Jardinier&);
    void destruction_plante();


    int get_grain();
    void set_grain(int);
    void GainGrain(Plante);
    void Affichage_Grain();
    void Affichage_prix();
    Champs();
    ~Champs();
};

#endif
