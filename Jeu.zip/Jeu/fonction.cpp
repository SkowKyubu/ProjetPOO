#include "fonction.h"
int bouton(int sx,int sy) //cette fonction permet de savoir sur quelle case clique le joueur
{
    int debut_x = 458; // correspond � la position du premier bouton
    int debut_y = 64;
    int indice_case = 0;

    for (int i=0;i<8;i++){
            for (int j=0;j<2;j++){
                indice_case+=1;

                if( debut_x + 36*2*j < sx && sx < debut_x +32 + 36*2*j && debut_y + 36*i < sy && sy < debut_y+ 32+36*i){
                    // Si l'utilisateur clique sur une case d'indice i on renvoie i
                    return indice_case;
                }
            }
    }

    if (debut_x +36 < sx && sx < debut_x +36 +32 && debut_y + 304 < sy && sy <debut_y +304 +32){
        return 17;
    }

    return 0;
}

/// FONCTIONS D'AFFICHAGE==========================================================================
CImg<unsigned char> animation(Champs& C,Jardinier& J)
{
    time_t ttime = time(0); // On enregistre le temps actuel

    // MORAL DU JARDINIER
    if(J.get_moral()>0 && ttime-J.get_date_changement_moral()>J.get_duree_etape_moral())
    {
        J.set_moral(J.get_moral()-1);
        J.set_date_changement_moral(ttime);
    }
    // ANIMATION DES JARDINIERS
    string trajet = construction_trajet_jardinier(C,J,C.garden.matrix);

    if(trajet.empty())
    {
        //Dans le cas o� je jardinier n'a pas d'objectif (pas de plante vers laquelle se diriger) on fait :
        J.set_visible(true);
        C.destruction_plante();
        C.draw_Jardinier();
        return C.image;
        // faire en sorte que le jardinier regarde dans tous les sens ou se d�place d'une case
    }
    else
    {
        if(J.get_visible()==true)
        {
            J.set_visible(false);
        }


        if(J.get_goal_x()!= J.get_position_previous_x()||
           J.get_goal_y()!= J.get_position_previous_y())
            C.deplacer_jardinier(J);

        if(J.get_etape_animation()<16)
        {
            C.image = animation_jardinier(C,J,trajet);//=> modifier pour �viter les superpositions
            J.set_etape_animation(J.get_etape_animation() + 1);
        }


        else{

            J.set_etape_animation(0);
            J.donner_orientation();
            C.image = animation(C,J);
        }
    }

return C.image;
}
// fonction d'animation lors de la marche d'un jardinier
CImg<unsigned char> animation_jardinier(Champs C,Jardinier J,string trajet)
{
int moral = J.get_moral(); //
int i = J.get_position_x(); //
int j = J.get_position_y(); //
int k = J.get_etape_animation();

CImg<unsigned char> save_image = C.image;
int debut_x = i*32;
int debut_y = j*32;
                    switch(trajet[0]){
                        case 'u':
                        {
                            CImg<unsigned char> img1;
                            CImg<unsigned char> img1o;
                            CImg<unsigned char> img2;
                            CImg<unsigned char> img2o;

                            if(moral ==3){
                            extern CImg<unsigned char> WalkTop_1_g;
                            extern CImg<unsigned char> WalkTop_1_go;
                            extern CImg<unsigned char> WalkTop_2_g;
                            extern CImg<unsigned char> WalkTop_2_go;
                            img1 = WalkTop_1_g;
                            img1o= WalkTop_1_go;
                            img2=WalkTop_2_g;
                            img2o=WalkTop_2_go;
                            }
                            else if(moral ==2)
                            {
                            extern CImg<unsigned char> WalkTop_1_y;
                            extern CImg<unsigned char> WalkTop_1_yo;
                            extern CImg<unsigned char> WalkTop_2_y;
                            extern CImg<unsigned char> WalkTop_2_yo;
                            img1 = WalkTop_1_y;
                            img1o= WalkTop_1_yo;
                            img2=WalkTop_2_y;
                            img2o=WalkTop_2_yo;
                            }
                            else
                            {
                            extern CImg<unsigned char> WalkTop_1_r;
                            extern CImg<unsigned char> WalkTop_1_ro;
                            extern CImg<unsigned char> WalkTop_2_r;
                            extern CImg<unsigned char> WalkTop_2_ro;
                            img1 = WalkTop_1_r;
                            img1o= WalkTop_1_ro;
                            img2=WalkTop_2_r;
                            img2o=WalkTop_2_ro;
                            };

                            if(k%2==0)
                            {
                                save_image.draw_image(debut_x,debut_y -4-2*k,img1,img1o);
                            }
                            else
                            {
                                save_image.draw_image(debut_x,debut_y-4-2*k,img2,img2o);
                            }
                            break;
                        }

                        case 'd':
                        {
                            CImg<unsigned char> img1;
                            CImg<unsigned char> img1o;
                            CImg<unsigned char> img2;
                            CImg<unsigned char> img2o;

                            if(moral ==3){
                            extern CImg<unsigned char> WalkDown_1_g;
                            extern CImg<unsigned char> WalkDown_1_go;
                            extern CImg<unsigned char> WalkDown_2_g;
                            extern CImg<unsigned char> WalkDown_2_go;
                            img1 = WalkDown_1_g;
                            img1o= WalkDown_1_go;
                            img2=WalkDown_2_g;
                            img2o=WalkDown_2_go;
                            }
                            else if(moral ==2)
                            {
                            extern CImg<unsigned char> WalkDown_1_y;
                            extern CImg<unsigned char> WalkDown_1_yo;
                            extern CImg<unsigned char> WalkDown_2_y;
                            extern CImg<unsigned char> WalkDown_2_yo;
                            img1 = WalkDown_1_y;
                            img1o= WalkDown_1_yo;
                            img2=WalkDown_2_y;
                            img2o=WalkDown_2_yo;
                            }
                            else
                            {
                            extern CImg<unsigned char> WalkDown_1_r;
                            extern CImg<unsigned char> WalkDown_1_ro;
                            extern CImg<unsigned char> WalkDown_2_r;
                            extern CImg<unsigned char> WalkDown_2_ro;
                            img1 = WalkDown_1_r;
                            img1o= WalkDown_1_ro;
                            img2=WalkDown_2_r;
                            img2o=WalkDown_2_ro;
                            }

                            if(k%2==0)
                            {
                                save_image.draw_image(debut_x,debut_y -4+2*k,img1,img1o);
                            }
                            else
                            {
                                save_image.draw_image(debut_x,debut_y-4+2*k,img2,img2o);
                            }
                            break;
                        }

                        case 'l':
                        {
                            CImg<unsigned char> img1;
                            CImg<unsigned char> img1o;
                            CImg<unsigned char> img2;
                            CImg<unsigned char> img2o;

                            if(moral ==3){
                            extern CImg<unsigned char> WalkLeft_1_g;
                            extern CImg<unsigned char> WalkLeft_1_go;
                            extern CImg<unsigned char> WalkLeft_2_g;
                            extern CImg<unsigned char> WalkLeft_2_go;
                            img1 = WalkLeft_1_g;
                            img1o= WalkLeft_1_go;
                            img2=WalkLeft_2_g;
                            img2o=WalkLeft_2_go;
                            }
                            else if(moral ==2)
                            {
                            extern CImg<unsigned char> WalkLeft_1_y;
                            extern CImg<unsigned char> WalkLeft_1_yo;
                            extern CImg<unsigned char> WalkLeft_2_y;
                            extern CImg<unsigned char> WalkLeft_2_yo;
                            img1 = WalkLeft_1_y;
                            img1o= WalkLeft_1_yo;
                            img2=WalkLeft_2_y;
                            img2o=WalkLeft_2_yo;
                            }
                            else
                            {
                            extern CImg<unsigned char> WalkLeft_1_r;
                            extern CImg<unsigned char> WalkLeft_1_ro;
                            extern CImg<unsigned char> WalkLeft_2_r;
                            extern CImg<unsigned char> WalkLeft_2_ro;
                            img1 = WalkLeft_1_r;
                            img1o= WalkLeft_1_ro;
                            img2=WalkLeft_2_r;
                            img2o=WalkLeft_2_ro;
                            }

                            if(k%2==0)
                            {
                                save_image.draw_image(debut_x-2*k,debut_y - 4,img1,img1o);
                            }
                            else
                            {
                                save_image.draw_image(debut_x-2*k,debut_y - 4 ,img2,img2o);
                            }
                            break;
                        }

                        case 'r':
                        {
                            CImg<unsigned char> img1;
                            CImg<unsigned char> img1o;
                            CImg<unsigned char> img2;
                            CImg<unsigned char> img2o;

                            if(moral ==3){
                            extern CImg<unsigned char> WalkRight_1_g;
                            extern CImg<unsigned char> WalkRight_1_go;
                            extern CImg<unsigned char> WalkRight_2_g;
                            extern CImg<unsigned char> WalkRight_2_go;
                            img1 = WalkRight_1_g;
                            img1o= WalkRight_1_go;
                            img2=WalkRight_2_g;
                            img2o=WalkRight_2_go;
                            }
                            else if(moral ==2)
                            {
                            extern CImg<unsigned char> WalkRight_1_y;
                            extern CImg<unsigned char> WalkRight_1_yo;
                            extern CImg<unsigned char> WalkRight_2_y;
                            extern CImg<unsigned char> WalkRight_2_yo;
                            img1 = WalkRight_1_y;
                            img1o= WalkRight_1_yo;
                            img2=WalkRight_2_y;
                            img2o=WalkRight_2_yo;
                            }
                            else
                            {
                            extern CImg<unsigned char> WalkRight_1_r;
                            extern CImg<unsigned char> WalkRight_1_ro;
                            extern CImg<unsigned char> WalkRight_2_r;
                            extern CImg<unsigned char> WalkRight_2_ro;
                            img1 = WalkRight_1_r;
                            img1o= WalkRight_1_ro;
                            img2=WalkRight_2_r;
                            img2o=WalkRight_2_ro;
                            }
                            if(k%2==0)
                            {
                                save_image.draw_image(debut_x+2*k,debut_y - 4,img1,img1o);
                            }
                            else
                            {
                                save_image.draw_image(debut_x+2*k,debut_y - 4 ,img2,img2o);
                            }
                            break;
                        }
                    }
    return save_image;
};


//Calcul de la distance entre deux points :

double distance(int x1,int y1,int x2,int y2)
{
    return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}


//Calcul de la plante � suivre la plus proche du jardinier, plante correspondant aux crit�res/conditions de jeu.

vector<int> PositionFleur(Jardinier J,vector<vector<Plante>> MP,int type)
{
    int xj = J.get_position_x();
    int yj = J.get_position_y();
    double sorter = 100000;

    vector<int> position(2,-1);
    int borne = MP.size();
        for(int i =0; i< borne;i++){
            for (int j=0;j<borne;j++)
            {
                if(MP[i][j].get_activation()==true &&
                   distance(xj,yj,i,j)<sorter &&
                   MP[i][j].get_etape_pousse()==5&&
                   MP[i][j].get_type()==type)
                    {
                    if(MP[i][j].get_desir_jardinier()==false ||
                       (J.get_goal_x()==i&&J.get_goal_y()==j))
                        {
                                sorter = distance(xj,yj,i,j);
                                position[0] = i;
                                position[1] = j;
                        }
                    }
            }}
    return position;
}

// Construction du trajet � suivre pour un jardinier � un instant t

string construction_trajet_jardinier(Champs& C,Jardinier& J,vector<vector<Plante>> MP)
{
    string trajet ="";
    int xj = J.get_position_x();
    int yj = J.get_position_y();
    vector<int> position_fleur(2,0);
    position_fleur = PositionFleur(J,MP,2);
    if(position_fleur[0]==-1 && J.get_moral()==1)
        position_fleur = PositionFleur(J,MP,1);
    int xp = position_fleur[0];
    int yp = position_fleur[1];
    if (xp==-1)
        return trajet;
    int distx = xp - xj;
    int disty = yp - yj;
    //int r = rand()%2
    if(distx >0)
    {
        for(int i=0;i<distx;i++)
        {
            trajet.push_back('r');
        }
    }
    else
    {
        for(int i=0;i<abs(distx);i++)
        {
            trajet.push_back('l');
        }
    }

    if(disty >0)
    {
        for(int i=0;i<disty;i++)
        {
            trajet.push_back('d');
        }
    }
    else
   {
        for(int i=0;i<abs(disty);i++)
        {
            trajet.push_back('u');
        }
    }

J.set_goal_x(xp);
J.set_goal_y(yp);
J.set_trajet(trajet);
J.set_orient(trajet);
return trajet;
}
