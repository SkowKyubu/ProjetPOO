/*#ifndef DEF_PLANTE_GRAIN
#define DEF_PLANTE_GRAIN
#include "CImg.h"
#include <iostream>
#include "Plante.h"

using namespace std;
using namespace cimg_library;


class PlanteGrain : public Plante{
private:
    int nombre_grain;
public:
    PlanteGrain();


};
#endif*/

