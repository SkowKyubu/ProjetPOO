#ifndef DEF_JARDINIER
#define DEF_JARDINIER
#include "CImg.h"
#include <iostream>
#include <ctime>
#include <vector>
#include <string>


using namespace std;
using namespace cimg_library;

class Jardinier
{
private:
    bool active {false};
    bool visible {false};
    int position_x;
    int position_y;
    int orientation;
    int moral;
    int duree_etape_moral;
    int date_changement_moral;
    string trajet;
    int etape_animation;
    int goal_x;
    int goal_y;
    int previous_x;
    int previous_y;
    int prix;
    char orient;
public:

    void activation(bool);
    bool get_activation();
    void set_visible(bool);
    bool get_visible();
    int get_position_x();
    void set_position_x(int);
    int get_position_y();
    void set_position_y(int);

    void set_position_previous_x(int);
    int get_position_previous_x();

    void set_position_previous_y(int);
    int get_position_previous_y();


    int get_moral();
    void set_moral(int);

    string get_trajet();
    void set_trajet(string);

    void set_date_changement_moral(int);
    int get_date_changement_moral();

    int get_duree_etape_moral();

    int get_etape_animation();
    void set_etape_animation(int);

    void donner_orientation();

    int get_goal_x();
    void set_goal_x(int);
    int get_goal_y();
    void set_goal_y(int);

    int get_prix();
    void set_prix(int);

    int get_orient();
    void set_orient(string);


    Jardinier();
    ~Jardinier();

};
#endif // DEF_JARDINIER
