#include "Plante.h"
/// ACTIVATION DES PLANTES ==========================================================
void Plante::activation(bool b)
{
    active = b;
}

bool Plante::get_activation()
{
    return active;
}

bool Plante::get_desir_jardinier()
{
    return wanted;
}

void Plante::set_desir_jardinier(bool b)
{
    wanted = b;
}

int Plante::get_code()
{
    return code;
}

void Plante::set_code(int c)
{
    code = c;
}

int Plante::get_type()
{
    if(code == 1 || code == 3)
        return 1;
    else
        return 2;
}

int Plante::get_duree_pousse()
{
    return duree_pousse;
}

void Plante::set_duree_pousse(int t)
{
    duree_pousse = t;
}

int Plante::get_date_plantation()
{
    return date_plantation;
}

void Plante::set_date_plantation(int t)
{
    date_plantation = t;
}

int Plante::get_etape_pousse()
{
    return etape_pousse;
}

void Plante::set_etape_pousse(int e)
{
    etape_pousse = e;
}

int Plante::get_QuantiteGrain()
{
    return QuantiteGrain;
}

void Plante::set_QuantiteGrain(int q)
{
    QuantiteGrain = q;
}

int Plante::get_prix()
{
    return prix;
}
void Plante::set_prix(int p)
{
    prix = p;
}

CImg<unsigned char> Plante::get_texture()
{
    return texture;
}

CImg<unsigned char> Plante::get_textureo()
{
    return textureo;
}

void Plante::set_recoltable(bool b)
{
    recoltable = b;
}

bool Plante::get_recoltable()
{
    return recoltable;
}

void Plante::set_texture(CImg<unsigned char> img,CImg<unsigned char> imgo)
{
    texture = img;
    textureo = imgo;
}

void Plante::pousse(int t) //permet de faire evoluer le stade de maturite des plantes. Prend en argument le temps actuel.
{
    if((get_etape_pousse()<5 && t-get_date_plantation()>get_duree_pousse()) || t==0) //On verifie que la plante n'est pas m�re + que la duree de pousse du stade de marurite n au stade de maturitee n+1 est atteinte.
    {
        etape_pousse = etape_pousse +1;
        set_date_plantation(t);

        if(code ==1){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> rose1;
                    extern CImg<unsigned char> rose1o;
                    texture = rose1;
                    textureo = rose1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> rose2;
                    extern CImg<unsigned char> rose2o;
                    texture = rose2;
                    textureo = rose2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> rose3;
                    extern CImg<unsigned char> rose3o;
                    texture = rose3;
                    textureo = rose3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> rose4;
                    extern CImg<unsigned char> rose4o;
                    texture = rose4;
                    textureo = rose4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> rose5;
                    extern CImg<unsigned char> rose5o;
                    texture = rose5;
                    textureo = rose5o;
                    break;
                }}}
        else if(code ==2){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> pineapple1;
                    extern CImg<unsigned char> pineapple1o;
                    texture = pineapple1;
                    textureo = pineapple1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> pineapple2;
                    extern CImg<unsigned char> pineapple2o;
                    texture = pineapple2;
                    textureo = pineapple2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> pineapple3;
                    extern CImg<unsigned char> pineapple3o;
                    texture = pineapple3;
                    textureo = pineapple3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> pineapple4;
                    extern CImg<unsigned char> pineapple4o;
                    texture = pineapple4;
                    textureo = pineapple4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> pineapple5;
                    extern CImg<unsigned char> pineapple5o;
                    texture = pineapple5;
                    textureo = pineapple5o;
                    break;
                }}}
        else if(code ==3){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> tulip1;
                    extern CImg<unsigned char> tulip1o;
                    texture = tulip1;
                    textureo = tulip1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> tulip2;
                    extern CImg<unsigned char> tulip2o;
                    texture = tulip2;
                    textureo = tulip2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> tulip3;
                    extern CImg<unsigned char> tulip3o;
                    texture = tulip3;
                    textureo = tulip3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> tulip4;
                    extern CImg<unsigned char> tulip4o;
                    texture = tulip4;
                    textureo = tulip4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> tulip5;
                    extern CImg<unsigned char> tulip5o;
                    texture = tulip5;
                    textureo = tulip5o;
                    break;
                }}}
        else if(code ==4){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> cucumber1;
                    extern CImg<unsigned char> cucumber1o;
                    texture = cucumber1;
                    textureo = cucumber1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> cucumber2;
                    extern CImg<unsigned char> cucumber2o;
                    texture = cucumber2;
                    textureo = cucumber2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> cucumber3;
                    extern CImg<unsigned char> cucumber3o;
                    texture = cucumber3;
                    textureo = cucumber3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> cucumber4;
                    extern CImg<unsigned char> cucumber4o;
                    texture = cucumber4;
                    textureo = cucumber4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> cucumber5;
                    extern CImg<unsigned char> cucumber5o;
                    texture = cucumber5;
                    textureo = cucumber5o;
                    break;
                }}}
        else if(code ==5){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> melon1;
                    extern CImg<unsigned char> melon1o;
                    texture = melon1;
                    textureo = melon1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> melon2;
                    extern CImg<unsigned char> melon2o;
                    texture = melon2;
                    textureo = melon2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> melon3;
                    extern CImg<unsigned char> melon3o;
                    texture = melon3;
                    textureo = melon3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> melon4;
                    extern CImg<unsigned char> melon4o;
                    texture = melon4;
                    textureo = melon4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> melon5;
                    extern CImg<unsigned char> melon5o;
                    texture = melon5;
                    textureo = melon5o;
                    break;
                }}}
        else if(code ==6){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> turnip1;
                    extern CImg<unsigned char> turnip1o;
                    texture = turnip1;
                    textureo = turnip1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> turnip2;
                    extern CImg<unsigned char> turnip2o;
                    texture = turnip2;
                    textureo = turnip2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> turnip3;
                    extern CImg<unsigned char> turnip3o;
                    texture = turnip3;
                    textureo = turnip3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> turnip4;
                    extern CImg<unsigned char> turnip4o;
                    texture = turnip4;
                    textureo = turnip4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> turnip5;
                    extern CImg<unsigned char> turnip5o;
                    texture = turnip5;
                    textureo = turnip5o;
                    break;
                }}}
        else if(code ==7){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> sunflower1;
                    extern CImg<unsigned char> sunflower1o;
                    texture = sunflower1;
                    textureo = sunflower1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> sunflower2;
                    extern CImg<unsigned char> sunflower2o;
                    texture = sunflower2;
                    textureo = sunflower2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> sunflower3;
                    extern CImg<unsigned char> sunflower3o;
                    texture = sunflower3;
                    textureo = sunflower3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> sunflower4;
                    extern CImg<unsigned char> sunflower4o;
                    texture = sunflower4;
                    textureo = sunflower4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> sunflower5;
                    extern CImg<unsigned char> sunflower5o;
                    texture = sunflower5;
                    textureo = sunflower5o;
                    break;
                }}}
        else if(code ==8){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> strawberry1;
                    extern CImg<unsigned char> strawberry1o;
                    texture = strawberry1;
                    textureo = strawberry1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> strawberry2;
                    extern CImg<unsigned char> strawberry2o;
                    texture = strawberry2;
                    textureo = strawberry2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> strawberry3;
                    extern CImg<unsigned char> strawberry3o;
                    texture = strawberry3;
                    textureo = strawberry3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> strawberry4;
                    extern CImg<unsigned char> strawberry4o;
                    texture = strawberry4;
                    textureo = strawberry4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> strawberry5;
                    extern CImg<unsigned char> strawberry5o;
                    texture = strawberry5;
                    textureo = strawberry5o;
                    break;
                }}}
        else if(code ==9){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> grapes1;
                    extern CImg<unsigned char> grapes1o;
                    texture = grapes1;
                    textureo = grapes1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> grapes2;
                    extern CImg<unsigned char> grapes2o;
                    texture = grapes2;
                    textureo = grapes2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> grapes3;
                    extern CImg<unsigned char> grapes3o;
                    texture = grapes3;
                    textureo = grapes3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> grapes4;
                    extern CImg<unsigned char> grapes4o;
                    texture = grapes4;
                    textureo = grapes4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> grapes5;
                    extern CImg<unsigned char> grapes5o;
                    texture = grapes5;
                    textureo = grapes5o;
                    break;
                }}}
        else if(code ==10){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> eggplant1;
                    extern CImg<unsigned char> eggplant1o;
                    texture = eggplant1;
                    textureo = eggplant1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> eggplant2;
                    extern CImg<unsigned char> eggplant2o;
                    texture = eggplant2;
                    textureo = eggplant2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> eggplant3;
                    extern CImg<unsigned char> eggplant3o;
                    texture = eggplant3;
                    textureo = eggplant3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> eggplant4;
                    extern CImg<unsigned char> eggplant4o;
                    texture = eggplant4;
                    textureo = eggplant4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> eggplant5;
                    extern CImg<unsigned char> eggplant5o;
                    texture = eggplant5;
                    textureo = eggplant5o;
                    break;
                }}}
        else if(code ==11){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> corn1;
                    extern CImg<unsigned char> corn1o;
                    texture = corn1;
                    textureo = corn1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> corn2;
                    extern CImg<unsigned char> corn2o;
                    texture = corn2;
                    textureo = corn2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> corn3;
                    extern CImg<unsigned char> corn3o;
                    texture = corn3;
                    textureo = corn3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> corn4;
                    extern CImg<unsigned char> corn4o;
                    texture = corn4;
                    textureo = corn4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> corn5;
                    extern CImg<unsigned char> corn5o;
                    texture = corn5;
                    textureo = corn5o;
                    break;
                }}}
        else if(code ==12){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> potato1;
                    extern CImg<unsigned char> potato1o;
                    texture = potato1;
                    textureo = potato1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> potato2;
                    extern CImg<unsigned char> potato2o;
                    texture = potato2;
                    textureo = potato2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> potato3;
                    extern CImg<unsigned char> potato3o;
                    texture = potato3;
                    textureo = potato3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> potato4;
                    extern CImg<unsigned char> potato4o;
                    texture = potato4;
                    textureo = potato4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> potato5;
                    extern CImg<unsigned char> potato5o;
                    texture = potato5;
                    textureo = potato5o;
                    break;
                }}}
        else if(code ==13){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> avocado1;
                    extern CImg<unsigned char> avocado1o;
                    texture = avocado1;
                    textureo = avocado1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> avocado2;
                    extern CImg<unsigned char> avocado2o;
                    texture = avocado2;
                    textureo = avocado2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> avocado3;
                    extern CImg<unsigned char> avocado3o;
                    texture = avocado3;
                    textureo = avocado3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> avocado4;
                    extern CImg<unsigned char> avocado4o;
                    texture = avocado4;
                    textureo = avocado4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> avocado5;
                    extern CImg<unsigned char> avocado5o;
                    texture = avocado5;
                    textureo = avocado5o;
                    break;
                }}}
        else if(code ==14){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> orange1;
                    extern CImg<unsigned char> orange1o;
                    texture = orange1;
                    textureo = orange1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> orange2;
                    extern CImg<unsigned char> orange2o;
                    texture = orange2;
                    textureo = orange2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> orange3;
                    extern CImg<unsigned char> orange3o;
                    texture = orange3;
                    textureo = orange3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> orange4;
                    extern CImg<unsigned char> orange4o;
                    texture = orange4;
                    textureo = orange4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> orange5;
                    extern CImg<unsigned char> orange5o;
                    texture = orange5;
                    textureo = orange5o;
                    break;
                }}}
        else if(code ==15){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> tomato1;
                    extern CImg<unsigned char> tomato1o;
                    texture = tomato1;
                    textureo = tomato1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> tomato2;
                    extern CImg<unsigned char> tomato2o;
                    texture = tomato2;
                    textureo = tomato2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> tomato3;
                    extern CImg<unsigned char> tomato3o;
                    texture = tomato3;
                    textureo = tomato3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> tomato4;
                    extern CImg<unsigned char> tomato4o;
                    texture = tomato4;
                    textureo = tomato4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> tomato5;
                    extern CImg<unsigned char> tomato5o;
                    texture = tomato5;
                    textureo = tomato5o;
                    break;
                }}}
        else if(code ==16){
                    switch(etape_pousse){
                case 1:{
                    extern CImg<unsigned char> lemon1;
                    extern CImg<unsigned char> lemon1o;
                    texture = lemon1;
                    textureo = lemon1o;
                    break;
                }
                case 2:{
                    extern CImg<unsigned char> lemon2;
                    extern CImg<unsigned char> lemon2o;
                    texture = lemon2;
                    textureo = lemon2o;
                    break;
                }
                case 3:{
                    extern CImg<unsigned char> lemon3;
                    extern CImg<unsigned char> lemon3o;
                    texture = lemon3;
                    textureo = lemon3o;
                    break;
                }
                case 4:{
                    extern CImg<unsigned char> lemon4;
                    extern CImg<unsigned char> lemon4o;
                    texture = lemon4;
                    textureo = lemon4o;
                    break;
                }
                case 5:{
                    extern CImg<unsigned char> lemon5;
                    extern CImg<unsigned char> lemon5o;
                    texture = lemon5;
                    textureo = lemon5o;
                    break;
                }}}
    }
}

Plante::~Plante()
{

}
