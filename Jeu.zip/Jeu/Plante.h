#ifndef DEF_PLANTE
#define DEF_PLANTE
#include <iostream>
#include <cstring>
#include "CImg.h"
#include "traitement_image.h"

using namespace std;
using namespace cimg_library;


class Plante{

private:
    bool active {false};                 //actif = plante visible sur le champ - inactif = plante invisible
    bool wanted {false};                 //permet de savoir si un jardinier veut cueuillir la plante

    int duree_pousse;                    //exprim�e en secondes
    int date_plantation;
    int etape_pousse;                    //stade de maturit� de la plante
    bool recoltable;                     //permet de savoir si c'est un type de plante r�coltable
    int QuantiteGrain;                   //Quantitee de grain rapporte par la recolte de la plante
    int prix;                            //prix de la plante
    CImg<unsigned char> texture;         //correspond � la texture de la plante
    CImg<unsigned char> textureo;        //correspond � la texture pour la transparence
    int code;                            //permet de diff�rentier les vari�t�s de plantes (le code est relatif aux emplacements des plantes dans le menu du jeu)

public:
    bool get_activation();
    void activation(bool);

    bool get_desir_jardinier();
    void set_desir_jardinier(bool);

    int get_code();
    void set_code(int);
    int get_type();

    CImg<unsigned char> get_texture();
    CImg<unsigned char> get_textureo();

    int get_duree_pousse();
    void set_duree_pousse(int);

    void set_date_plantation(int);
    int get_date_plantation();
    int get_etape_pousse();

    int get_QuantiteGrain();
    void set_QuantiteGrain(int);

    int get_prix();
    void set_prix(int);

    void set_etape_pousse(int);
    void set_texture(CImg<unsigned char>,CImg<unsigned char>);
    bool get_recoltable();
    void set_recoltable(bool);
    void pousse(int);

    ~Plante();
};
#endif
