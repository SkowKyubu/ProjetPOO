#include "Legume.h"

Legume::Legume(int code_legume)
{
    activation(true);
    set_recoltable(true);
    set_etape_pousse(0);
    if (code_legume==2)
    {
        set_code(2);
        set_prix(3);
        set_duree_pousse(10); // DUREE POUSSE
        extern CImg<unsigned char> pineapple0;
        extern CImg<unsigned char> pineapple0o;
        set_texture(pineapple0,pineapple0o);
        set_QuantiteGrain(2);
    }

    else if (code_legume==4)
    {
        set_code(4);
        set_prix(3);
        set_duree_pousse(4); // DUREE POUSSE
        extern CImg<unsigned char> cucumber0;
        extern CImg<unsigned char> cucumber0o;
        set_texture(cucumber0,cucumber0o);
        set_QuantiteGrain(2);
    }

    else if (code_legume==5)
    {
        set_code(5);
        set_prix(3);
        set_duree_pousse(4); // DUREE POUSSE
        extern CImg<unsigned char> melon0;
        extern CImg<unsigned char> melon0o;
        set_texture(melon0,melon0o);
        set_QuantiteGrain(2);
    }

    else if (code_legume==6)
    {
        set_code(6);
        set_prix(5);
        set_duree_pousse(4); // DUREE POUSSE
        extern CImg<unsigned char> turnip0;
        extern CImg<unsigned char> turnip0o;
        set_texture(turnip0,turnip0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==7)
    {
        set_code(7);
        set_prix(3);
        set_duree_pousse(10); // DUREE POUSSE
        extern CImg<unsigned char> sunflower0;
        extern CImg<unsigned char> sunflower0o;
        set_texture(sunflower0,sunflower0o);
        set_QuantiteGrain(20);
    }
    else if (code_legume==8)
    {
        set_code(8);
        set_prix(3);
        set_duree_pousse(4); // DUREE POUSSE
        extern CImg<unsigned char> strawberry0;
        extern CImg<unsigned char> strawberry0o;
        set_texture(strawberry0,strawberry0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==9)
    {
        set_code(9);
        set_prix(3);
        set_duree_pousse(4); // DUREE POUSSE
        extern CImg<unsigned char> grapes0;
        extern CImg<unsigned char> grapes0o;
        set_texture(grapes0,grapes0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==10)
    {
        set_code(10);
        set_prix(3);
        set_duree_pousse(1); // DUREE POUSSE
        extern CImg<unsigned char> eggplant0;
        extern CImg<unsigned char> eggplant0o;
        set_texture(eggplant0,eggplant0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==11)
    {
        set_code(11);
        set_prix(3);
        set_duree_pousse(1); // DUREE POUSSE
        extern CImg<unsigned char> corn0;
        extern CImg<unsigned char> corn0o;
        set_texture(corn0,corn0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==12)
    {
        set_code(12);
        set_prix(3);
        set_duree_pousse(1); // DUREE POUSSE
        extern CImg<unsigned char> potato0;
        extern CImg<unsigned char> potato0o;
        set_texture(potato0,potato0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==13)
    {
        set_code(13);
        set_prix(3);
        set_duree_pousse(1); // DUREE POUSSE
        extern CImg<unsigned char> avocado0;
        extern CImg<unsigned char> avocado0o;
        set_texture(avocado0,avocado0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==14)
    {
        set_code(14);
        set_prix(3);
        set_duree_pousse(1); // DUREE POUSSE
        extern CImg<unsigned char> orange0;
        extern CImg<unsigned char> orange0o;
        set_texture(orange0,orange0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==15)
    {
        set_code(15);
        set_prix(3);
        set_duree_pousse(1); // DUREE POUSSE
        extern CImg<unsigned char> tomato0;
        extern CImg<unsigned char> tomato0o;
        set_texture(tomato0,tomato0o);
        set_QuantiteGrain(2);
    }
    else if (code_legume==16)
    {
        set_code(16);
        set_prix(2);
        set_duree_pousse(1); // DUREE POUSSE
        extern CImg<unsigned char> lemon0;
        extern CImg<unsigned char> lemon0o;
        set_texture(lemon0,lemon0o);
        set_QuantiteGrain(2);
    }
}

