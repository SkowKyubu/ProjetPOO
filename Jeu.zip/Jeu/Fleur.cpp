#include "Fleur.h"

/// CONSTRUCTEUR ==============================================================================
Fleur::Fleur(int code_fleur)
{
    activation(true);
    set_recoltable(false);   // Les fleurs ne sont pas r�coltables : ne rapportent pas de grain
    set_etape_pousse(0);     // Initialisation de la fleur � son stade 0 de maturit�
    if(code_fleur == 1)
    {
        set_code(1);
        int pr1 = 1;
        set_prix(pr1);
        set_duree_pousse(1); // DUREE POUSSE

        /// Chargement des textures =====
        extern CImg<unsigned char> rose0;
        extern CImg<unsigned char> rose0o;
        set_texture(rose0,rose0o);
        /// =============================
    }

    else if (code_fleur == 3)
    {
        set_code(3);
        set_prix(1);
        set_duree_pousse(2); // DUREE POUSSE

        /// Chargement des textures =====
        extern CImg<unsigned char> tulip0;
        extern CImg<unsigned char> tulip0o;
        set_texture(tulip0,tulip0o);
        /// =============================
    }
}

/// DESTRUCTEUR ============================================================================
Fleur::~Fleur()
{

}
