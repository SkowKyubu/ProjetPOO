#include "Champs.h"
int Champs::get_nombre_grain()
{
    return nombre_grain;
}

int Champs::get_nombre_jardinier()
{
    return nombre_jardinier;
}

void Champs::set_nombre_grain(int x)
{
    nombre_grain = x;
}

void Champs::set_nombre_jardinier(int x)
{
    nombre_jardinier = x;
}

void Champs::placer_jardinier(Jardinier& J, int i, int j)
{
    time_t ttime = time(0);
    J.set_date_changement_moral(ttime);  // On marque la date o� le jardinier a �t� pos�

    J.activation(true);                  // On active le jardinier afin de le rendre actif dans le jeu
    J.set_visible(true);                 // On le rend visible � l'affichage
    J.set_position_x(i);
    J.set_position_y(j);
    J.set_goal_x(i);                     // Le jardinier n'a pas de plante en objectif au depart
    J.set_goal_y(j);
    J.set_position_previous_x(i);        // Le jardinier ne s'est pas d�plac� : pas d'emplacement anterieur
    J.set_position_previous_y(j);
    matrix_jardinier[i][j] = J;          //Le jardinier est plac� dans la matrice de jardinier
}

void Champs::deplacer_jardinier(Jardinier& J)
{
    int i1 = J.get_position_previous_x();
    int j1 = J.get_position_previous_y();
    garden.matrix[i1][j1].set_desir_jardinier(false);
    int i2 = J.get_goal_x();
    int j2 = J.get_goal_y();
    garden.matrix[i2][j2].set_desir_jardinier(true);
    J.set_position_previous_x(i2);
    J.set_position_previous_y(j2);

    matrix_jardinier[i2][j2] = J;
    matrix_jardinier[i1][j1].activation(false);
    matrix_jardinier[i1][j1].set_visible(false);
    matrix_jardinier[i1][i1].set_trajet("");
}


void Champs::draw_Jardinier()
{
    ///VERT ================================
    extern CImg<unsigned char> WaitDown_g;
    extern CImg<unsigned char> WaitDown_go;

    extern CImg<unsigned char> WaitTop_g;
    extern CImg<unsigned char> WaitTop_go;

    extern CImg<unsigned char> WaitLeft_g;
    extern CImg<unsigned char> WaitLeft_go;

    extern CImg<unsigned char> WaitRight_g;
    extern CImg<unsigned char> WaitRight_go;

    /// JAUNE ===========================

    extern CImg<unsigned char> WaitDown_y;
    extern CImg<unsigned char> WaitDown_yo;

    extern CImg<unsigned char> WaitTop_y;
    extern CImg<unsigned char> WaitTop_yo;

    extern CImg<unsigned char> WaitLeft_y;
    extern CImg<unsigned char> WaitLeft_yo;

    extern CImg<unsigned char> WaitRight_y;
    extern CImg<unsigned char> WaitRight_yo;

    /// ROUGE ============================
    extern CImg<unsigned char> WaitDown_r;
    extern CImg<unsigned char> WaitDown_ro;

    extern CImg<unsigned char> WaitTop_r;
    extern CImg<unsigned char> WaitTop_ro;

    extern CImg<unsigned char> WaitLeft_r;
    extern CImg<unsigned char> WaitLeft_ro;

    extern CImg<unsigned char> WaitRight_r;
    extern CImg<unsigned char> WaitRight_ro;

    CImg<unsigned char> img;
    CImg<unsigned char> imgo;

    for(int i=0;i<14;i++){
        for (int j=0;j<14;j++)
        {
            //Les lignes ci-dessous permettent de mettre � jour l'image du jardinier en fonction de son moral et de son orientation
            Jardinier& J = matrix_jardinier[i][j];
            if ((matrix_jardinier[i][j]).get_activation() == true && matrix_jardinier[i][j].get_visible() == true){
                int moral_jardinier = matrix_jardinier[i][j].get_moral();
                if(moral_jardinier == 3){
                    if(J.get_orient()=='u')
                        {
                            img = WaitTop_g;
                            imgo = WaitTop_go;
                        }
                    else if(J.get_orient()=='r')
                        {
                            img = WaitRight_g;
                            imgo = WaitRight_go;
                        }
                    else if(J.get_orient()=='l')
                        {
                            img = WaitLeft_g;
                            imgo = WaitLeft_go;
                        }
                    else
                        {
                            img = WaitDown_g;
                            imgo = WaitDown_go;
                        }
                    }
                else if(moral_jardinier==2){
                    if(J.get_orient()=='u')
                        {
                            img = WaitTop_y;
                            imgo = WaitTop_yo;
                        }
                    else if(J.get_orient()=='r')
                        {
                            img = WaitRight_y;
                            imgo = WaitRight_yo;
                        }
                    else if(J.get_orient()=='l')
                        {
                            img = WaitLeft_y;
                            imgo = WaitLeft_yo;
                        }
                    else
                        {
                            img = WaitDown_y;
                            imgo = WaitDown_yo;
                        }
                    }
                else{
                    if(J.get_orient()=='u')
                        {
                            img = WaitTop_r;
                            imgo = WaitTop_ro;
                        }
                    else if(J.get_orient()=='r')
                        {
                            img = WaitRight_r;
                            imgo = WaitRight_ro;
                        }
                    else if(J.get_orient()=='l')
                        {
                            img = WaitLeft_r;
                            imgo = WaitLeft_ro;
                        }
                    else
                        {
                            img = WaitDown_r;
                            imgo = WaitDown_ro;
                        }
                    }

                image.draw_image(i*32,j*32-4,img,imgo);}
        }
    }
}



void Champs::destruction_plante()
{
    for(int i=0;i<14;i++){
        for(int j=0;j<14;j++){
                Jardinier& J = matrix_jardinier[i][j];
                Plante& P = garden.matrix[i][j];
                if (J.get_activation()==true && J.get_visible()==true)
                {
                    if(P.get_activation()==true && P.get_etape_pousse()==5)
                    {
                        if(J.get_moral() == 3)             // Si le moral est au top on recolte le legume
                            {GainGrain(P);                 // On r�colte les grains de la plante
                            P.set_etape_pousse(1);         // La plante revient � son stade 1 de maturit�
                            P.pousse(0);                   // Actualisation de la plante
                            }
                        else if(J.get_moral()==2)
                        {
                            int n = rand()%2;              //si le moral est moyen, on ramasse OU on mange le legume al�atoirement
                            if(n==0)
                            {
                              GainGrain(P);                // On r�colte les grains de la plante
                              P.set_etape_pousse(1);       // La plante revient � son stade 1 de maturit�
                              P.pousse(0);                 // Actualisation de la plante
                            }

                            else
                            {
                                Plante nouveau;            //moral bas on mange le legume
                                P = nouveau;
                                J.set_moral(3);            //Le moral augmente apr�s avoir mang�

                            }
                        }
                        else                               //Moral du jardinier au plus bas
                        {
                            Plante nouveau;                //On ne peut que manger des plantes ou les d�truire (fleurs)
                            if(P.get_code()!=1 && P.get_code()!=3)
                                J.set_moral(3);            //Dans le cas o� la plante en question n'est pas une fleur, le jardinier mange la plante et son moral remonte
                            P = nouveau;

                        }
                    }
                }
        }
    }
}

int Champs::get_grain()
{
    return nombre_grain;
}

void Champs::set_grain(int g)
{
    nombre_grain = g;
}

void Champs::GainGrain(Plante P) //permet d'ajouter des graines � la banque de grain
{
    nombre_grain += P.get_QuantiteGrain();
}

void Champs::Affichage_Grain()  //Permet d'afficher les grains dans la fen�tre de jeu
{
    string s = std::to_string(get_nombre_grain());
    int borne = s.size();
    for (int k;k<borne;k++)
    {
        CImg<unsigned char> img = NumToImg(s[k]);
        CImg<unsigned char> imgo = NumToImgo(s[k]);
        image.draw_image(16+k*16,0,img,imgo);
    }

int T[16] {0};
T[0] = 7;
T[1] = 3;
T[2] = 3;
T[3] = 3;
T[4] = 3;
T[5] = 5;
T[6] = 3;
T[7] = 3;
T[8] = 3;
T[9] = 3;
T[10] = 3;
T[11] = 3;
T[12] = 3;
T[13] = 3;
T[14] = 3;
T[15] = 2;

int debut_x = 458;
int debut_y = 64;
int indice_case = 0;

// Les boucles ci-dessous permettent d'afficher le prix de chaque l�gumes dans le menu
for (int i=0;i<8;i++){
        for (int j=0;j<2;j++){
                indice_case+=1;

                string s = std::to_string(T[indice_case -1]);
                int borne = s.size();
                for (int k=0;k<borne;k++)
                {
                    CImg<unsigned char> img = NumToImg(s[k]);
                    CImg<unsigned char> imgo = NumToImgo(s[k]);
                    image.draw_image(debut_x + 36*2*j + 36 + 9,debut_y + 36*i ,img,imgo);

                }
        }
}

// Les lignes c-dessous permettent l'affichage du tarif du jardinier
int TJ = 5; // prix d'un jardinier
s = std::to_string(TJ);
                borne = s.size();
                for (int k=0;k<borne;k++)
                {
                    CImg<unsigned char> img = NumToImg(s[k]);
                    CImg<unsigned char> imgo = NumToImgo(s[k]);
                    image.draw_image(debut_x + 2*36 + 9,368 ,img,imgo);

                }
}

/// CONSTRUCTEURS ===============================================================================
Champs::Champs()
{
    nombre_grain = 30;                                               //Nombre initial de grain en d�but de jeu
    image = garden.draw_Jardin();
    vector<vector<Jardinier>> matrix_ini(14, vector<Jardinier>(14)); //initialisation de la matrice du jardin
    matrix_jardinier = matrix_ini;
}

Champs::~Champs()
{

}
