#include <iostream>
#include <cmath>
#include <thread>
#include "Champs.h"
#include "Plante.h"
#include "Fleur.h"
#include "PlanteGrain.h"
#include "Legume.h"
#include "fonction.h"
#include "traitement_image.h"
using namespace std;

int main()
{
    Champs C;
    Plante F;
    Jardinier toto;
    bool selection = false; //Tant qu'une selection de plante n'a pas �t� faite, on ne peut rien planter
    int type_selection;     // 0 pour une plante, 1 pour un jardinier
    CImgDisplay disp(C.image,"Garden Simulator");

/// ==========================================================================================
    while (not disp.is_closed())
    {
    C.image = C.garden.draw_Jardin(); // On r�initialise le jardin � chaque tour de boucle
/// GESTION DU TEMPS DE POUSSE================================================================
        for(int i=0;i<14;i++)
        {
            for(int j=0;j<14;j++)
            {
                if(C.garden.matrix[i][j].get_activation()==true)
                {
                        Plante P;
                        time_t ttime = time(0);
                        C.garden.matrix[i][j].pousse(ttime);
                }
            }
        }

/// PARTIE DEPLACEMENT JARDINIER=========================================================================
      for(int i=0;i<14;i++){
            for(int j=0;j<14;j++){
                Jardinier &J = C.matrix_jardinier[i][j];
                if(J.get_activation()==true)
                {
                    C.image = animation(C,J);
                }
            }}
/// AFFICHAGE DU NOMBRE DE GRAINES======================================================================
      C.Affichage_Grain();
/// PARTIE AFFICHAGE GENERAL ===========================================================================
      disp.wait(35);


      disp.display(C.image);
/// PARTIE PLANTAGE=====================================================================================

    if (disp.button()&1 && 32 < disp.mouse_x() &&  disp.mouse_x()<13*32 && 32 < disp.mouse_y() && disp.mouse_y()<13*32&& selection == true && //on verifie que l'utilisateur clique bien dans le champs et qu'il a bien selectionner un element � planter
        C.garden.matrix[floor(disp.mouse_x()/32)][floor(disp.mouse_y()/32)].get_activation()==false && //on verifie qu'il n'essaie pas de poser un element(plante/jardinier) sur une plante d�j� pr�sente
            C.matrix_jardinier[floor(disp.mouse_x()/32)][floor(disp.mouse_y()/32)].get_activation()==false) // m�me chose sur un jardinier dej� pr�sent
            {
                switch(type_selection) //permet de savoir quel type de selection a �t� fait : jardinier ou plante //S
                {
                    case 0: //code plante
                        C.set_grain(C.get_grain()-F.get_prix());
                        C.garden.planter(F,floor(disp.mouse_x()/32),floor(disp.mouse_y()/32));
                        break;
                    case 1: // code jardinier
                        C.set_grain(C.get_grain()-toto.get_prix());
                        C.placer_jardinier(toto,floor(disp.mouse_x()/32),floor(disp.mouse_y()/32));
                        break;
                }
                selection = false;
            }

///PARTIE LIEE A LA SELECTION DES BOUTONS====================================================
    if (disp.button()&1)
    {
        switch(bouton(disp.mouse_x(),disp.mouse_y())){
            case 1:{
                Fleur rose(1);
                if(rose.get_prix()<=C.get_grain())
                {
                    F = rose;
                    type_selection = 0;
                    selection = true;
                }
                break;
            }
            case 2:{
                Legume pineapple(2);
                if(pineapple.get_prix()<=C.get_grain())
                {
                    F = pineapple;
                    type_selection = 0;
                    selection = true;
                }

                break;
            }
            case 3:{
                Fleur tulip(3);
                if(tulip.get_prix()<=C.get_grain())
                {
                    F = tulip;
                    type_selection = 0;
                    selection = true;
                }
                break;
            }
            case 4:{
                Legume cucumber(4);
                if(cucumber.get_prix()<=C.get_grain())
                {
                    F = cucumber;
                    type_selection = 0;
                    selection = true;
                }

                break;
            }
            case 5:{
                Legume melon(5);
                if(melon.get_prix()<=C.get_grain())
                {
                    F = melon;
                    type_selection = 0;
                    selection = true;
                }

                break;
                }
            case 6:{
                Legume turnip(6);
                if(turnip.get_prix()<=C.get_grain())
                {
                    F = turnip;
                    type_selection = 0;
                    selection = true;
                }

                break;
            }
            case 7:{
                Legume sunflower(7);
                if(sunflower.get_prix()<=C.get_grain())
                {
                    F = sunflower;
                    type_selection = 0;
                    selection = true;
                }

                break;
            }
            case 8:
                {
                Legume strawberry(8);
                if(strawberry.get_prix()<=C.get_grain())
                {
                    F = strawberry;
                    type_selection = 0;
                    selection = true;
                }

                break;
                }
            case 9:
                {
                Legume grapes(9);
                if(grapes.get_prix()<=C.get_grain())
                {
                    F = grapes;
                    type_selection = 0;
                    selection = true;
                }
                break;
                }
            case 10:
                {
                Legume eggplant(10);
                if(eggplant.get_prix()<=C.get_grain())
                {
                    F = eggplant;
                    type_selection = 0;
                    selection = true;
                }
                break;
                }
            case 11:
                {
                Legume corn(11);
                if(corn.get_prix()<=C.get_grain())
                {
                    F = corn;
                    type_selection = 0;
                    selection = true;
                }
                break;
                }
            case 12:
                {
                Legume potato(12);
                if(potato.get_prix()<=C.get_grain())
                {
                    F = potato;
                    type_selection = 0;
                    selection = true;
                }

                break;
                }
            case 13:
                {
                Legume avocado(13);
                if(avocado.get_prix()<=C.get_grain())
                {
                    F = avocado;
                    type_selection = 0;
                    selection = true;
                }
                break;
                }
            case 14:
                {
                Legume orange(14);
                if(orange.get_prix()<=C.get_grain())
                {
                    F = orange;
                    type_selection = 0;
                    selection = true;
                }
                break;
                }
            case 15:
                {
                Legume tomato(15);
                if(tomato.get_prix()<=C.get_grain())
                {
                    F = tomato;
                    type_selection = 0;
                    selection = true;
                }
                break;
                }
            case 16:
                {
                Legume lemon(16);
                if(lemon.get_prix()<=C.get_grain())
                {
                    F = lemon;
                    type_selection = 0;
                    selection = true;
                }
                break;
                }
            case 17:
                {
                    if(toto.get_prix()<=C.get_grain())
                    {
                    type_selection = 1;
                    selection = true;
                    }

                break;
                }
            }
        }
    }
}
