#ifndef DEF_FONCTION
#define DEF_FONCTION
#include "CImg.h"
#include <iostream>
#include <chrono>
#include <vector>
#include <stdlib.h>
#include <cmath>
#include <string>
#include "Champs.h"
#include "traitement_image.h"
#include "Jardinier.h"
#include "Plante.h"

using namespace std;

int bouton(int,int);
double distance(int,int,int,int);
CImg<unsigned char> animation(Champs&,Jardinier&);
CImg<unsigned char> animation_jardinier(Champs,Jardinier,string);
vector<int> PositionFleur(Jardinier,vector<vector<Plante>>,int type);
string construction_trajet_jardinier(Champs&,Jardinier&,vector<vector<Plante>>);
#endif
