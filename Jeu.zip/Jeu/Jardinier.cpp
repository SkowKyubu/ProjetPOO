#include "Jardinier.h"
/// ACTIVATION==============================
void Jardinier::activation(bool b)
{
    active = b;
}
bool Jardinier::get_activation()
{
    return active;
}
/// VISIBLE ================================
void Jardinier::set_visible(bool b)
{
    visible = b;
}
bool Jardinier::get_visible()
{
    return visible;
}
/// POSITION ANIMATION =====================
void Jardinier::set_position_x(int x)
{
    position_x = x;
}
int Jardinier::get_position_x()
{
    return position_x;
}
void Jardinier::set_position_y(int y)
{
    position_y = y;
}
int Jardinier::get_position_y()
{
    return position_y;
}
/// POSITION INITIALE DANS LA MATRICE =======
void Jardinier::set_position_previous_x(int x)
{
    previous_x = x;
}
int Jardinier::get_position_previous_x()
{
    return previous_x;
}
void Jardinier::set_position_previous_y(int y)
{
    previous_y = y;
}
int Jardinier::get_position_previous_y()
{
    return previous_y;
}
/// POSITION CIBLEE DANS LA MATRICE =========
void Jardinier::set_goal_x(int x)
{
    goal_x = x;
}
int Jardinier::get_goal_x()
{
    return goal_x;
}
void Jardinier::set_goal_y(int y)
{
    goal_y = y;
}
int Jardinier::get_goal_y()
{
    return goal_y;
}
/// MORAL DU JARDINIER========================
void Jardinier::set_moral(int m)
{
    moral = m;
}
int Jardinier::get_moral()
{
    return moral;
}
void Jardinier::set_date_changement_moral(int d)
{
    date_changement_moral = d;
}
int Jardinier::get_date_changement_moral()
{
    return date_changement_moral;
}
int Jardinier::get_duree_etape_moral()
{
    return duree_etape_moral;
}
/// TRAJET DU JARDINIER VERS CIBLE ===========
void Jardinier::set_trajet(string s)
{
    trajet =s;
}
string Jardinier::get_trajet()
{
    return trajet;
}
/// ETAPE ANIMATION MARCHE DU JARDINIER ======
void Jardinier::set_etape_animation(int e)
{
    etape_animation = e;
}
int Jardinier::get_etape_animation()
{
    return etape_animation;
}
void Jardinier::donner_orientation()
{
    switch(trajet[0]){
case 'u':{
    position_y -= 1;
    break;
}
case 'd':{
    position_y += 1;
    break;
}
case 'l':{
    position_x -= 1;
    break;
}
case 'r':{
    position_x += 1;
    break;
}
}
}

int Jardinier::get_prix()
{
    return prix;
}
void Jardinier::set_prix(int p)
{
    prix = p;
}

int Jardinier::get_orient()
{
    return orient;
}

void Jardinier::set_orient(string trajet)
{
    if (trajet.empty()!=1)
    {
        orient = trajet[0];
    }
}

/// CONSTRUCTEURS ===========================
Jardinier::Jardinier()
{
    prix = 5;
    goal_x = -1;
    goal_y = -1;
    moral = 3;
    duree_etape_moral = 10;
    etape_animation = 0;
    set_trajet("");
}
Jardinier::~Jardinier()
{

}
