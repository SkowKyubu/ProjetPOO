#include "CImg.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <vector>
#include <cmath>
#include <string>
#include "Jardinier.h"
#include "Plante.h"
using namespace std;

CImg<unsigned char> img_opacite(CImg<unsigned char>);
CImg<unsigned char> NumToImg(char);
CImg<unsigned char> NumToImgo(char);
