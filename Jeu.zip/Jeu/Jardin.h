#include <iostream>
#include <vector>
#include <ctime>
#include "CImg.h"
#include "Plante.h"
#include "traitement_image.h"

using namespace std;
using namespace cimg_library;

class Jardin{
private:
    int dimension_x;
    int dimension_y;

public:
    vector<vector<Plante>> matrix;
    int get_dimension_x();
    int get_dimension_y();
    void set_dimension_x(int);
    void set_dimension_y(int);

    Jardin();
    CImg<unsigned char> draw_Jardin();                      //permet de tracer le champ (sert d'initialisation)
    void planter(Plante,int,int);
    ~Jardin();
};
