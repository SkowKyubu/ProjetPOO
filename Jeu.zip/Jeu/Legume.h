#ifndef DEF_LEGUME
#define DEF_LEGUME
#include "CImg.h"
#include <iostream>
#include "Plante.h"

using namespace std;
using namespace cimg_library;


class Legume : public Plante{
public:
    Legume(int);

};
#endif

