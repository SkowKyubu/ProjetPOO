/*#include "PlanteGrain.h"

PlanteGrain::PlanteGrain()
{
    set_recoltable(true);
}*/
