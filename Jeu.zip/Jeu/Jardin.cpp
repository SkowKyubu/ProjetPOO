#include "Jardin.h"

int Jardin::get_dimension_x()
{
    return dimension_x;
}

int Jardin::get_dimension_y()
{
    return dimension_y;
}

void Jardin::set_dimension_x(int x)
{
    dimension_x = x;
}

void Jardin::set_dimension_y(int y)
{
    dimension_y = y;
}

//permet de tracer le jardin vide
CImg<unsigned char> Jardin::draw_Jardin()
{
    unsigned char color_background[3] {0,128,0};                                              //d�finition de la couleur du jardin
    CImg<unsigned char> mon_image(dimension_x*32 + 16*10,dimension_y*32,1,3);                 //d�finition de la fen�tre
    CImg<unsigned char> menu("image/menu.pnm");
    CImg<unsigned char> mapbackground("image/map.pnm");


    mon_image.draw_rectangle(0,0,dimension_x*32,dimension_y*32,color_background);             //Affichage du jardin
    mon_image.draw_image(dimension_x*32 +1 ,0,menu);
    mon_image.draw_image(0 ,0,mapbackground);

    for(int i=0;i<get_dimension_x();i++){
        for (int j=0;j<get_dimension_y();j++)
        {
            if ((matrix[i][j]).get_activation() == true)
            {
                Plante P = matrix[i][j];
                mon_image.draw_image(i*32,j*32,P.get_texture(),P.get_textureo());                              //permet l'affichage des fleurs dans le jardin
            }
        }
    }

    return mon_image;
}

void Jardin::planter(Plante P, int i, int j) //permet de planter une plante dans le jardin
{

    time_t ttime = time(0);
    P.set_date_plantation(ttime);
    matrix[i][j] = P;

}
/// CONSTRUCTEUR ================================================================================
Jardin::Jardin()
{
    set_dimension_x(14);
    set_dimension_y(14);
    vector<vector<Plante>> matrix_ini(get_dimension_x(), vector<Plante>(get_dimension_y())); //initialisation de la matrice du jardin
    matrix = matrix_ini;
}

/// DESTRUCTEUR =================================================================================
Jardin::~Jardin()
{

}
