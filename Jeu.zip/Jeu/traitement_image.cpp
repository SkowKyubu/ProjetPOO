#include "traitement_image.h"
CImg<unsigned char> img_opacite(CImg<unsigned char> image) // pour retirer l'opacite
{
  CImg<float> opacite(image.width(), image.height(), 1, 1, 0);
  for(int x=0; x<opacite.width(); ++x)
  for(int y=0; y<opacite.height(); ++y)
  if (image(x,y,0)==255 and image(x,y,1)==255 and image(x,y,2)==255)
        opacite(x,y)=0;
  else
        opacite(x,y)=1;
  image.draw_image(0,0,0,0,image,opacite);
  return opacite;
}




/// IMPORTATIPON DES IMAGES ===========================================================
// Jardinier : vert
CImg<unsigned char> WaitTop_g("Jardinier/green/WaitTop.pnm");
CImg<unsigned char> WaitTop_go = img_opacite(WaitTop_g);

CImg<unsigned char> WalkTop_1_g("Jardinier/green/WalkTop_1.pnm");
CImg<unsigned char> WalkTop_1_go = img_opacite(WalkTop_1_g);

CImg<unsigned char> WalkTop_2_g("Jardinier/green/WalkTop_2.pnm");
CImg<unsigned char> WalkTop_2_go = img_opacite(WalkTop_2_g);
////
CImg<unsigned char> WaitDown_g("Jardinier/green/WaitDown.pnm");
CImg<unsigned char> WaitDown_go = img_opacite(WaitDown_g);

CImg<unsigned char> WalkDown_1_g("Jardinier/green/WalkDown_1.pnm");
CImg<unsigned char> WalkDown_1_go = img_opacite(WalkDown_1_g);

CImg<unsigned char> WalkDown_2_g("Jardinier/green/WalkDown_2.pnm");
CImg<unsigned char> WalkDown_2_go = img_opacite(WalkDown_2_g);
////
CImg<unsigned char> WaitLeft_g("Jardinier/green/WaitLeft.pnm");
CImg<unsigned char> WaitLeft_go = img_opacite(WaitLeft_g);

CImg<unsigned char> WalkLeft_1_g("Jardinier/green/WalkLeft_1.pnm");
CImg<unsigned char> WalkLeft_1_go = img_opacite(WalkLeft_1_g);

CImg<unsigned char> WalkLeft_2_g("Jardinier/green/WalkLeft_2.pnm");
CImg<unsigned char> WalkLeft_2_go = img_opacite(WalkLeft_2_g);
////
CImg<unsigned char> WaitRight_g("Jardinier/green/WaitRight.pnm");
CImg<unsigned char> WaitRight_go = img_opacite(WaitRight_g);

CImg<unsigned char> WalkRight_1_g("Jardinier/green/WalkRight_1.pnm");
CImg<unsigned char> WalkRight_1_go = img_opacite(WalkRight_1_g);

CImg<unsigned char> WalkRight_2_g("Jardinier/green/WalkRight_2.pnm");
CImg<unsigned char> WalkRight_2_go = img_opacite(WalkRight_2_g);

// Jardinier : jaune
CImg<unsigned char> WaitTop_y("Jardinier/yellow/WaitTop.pnm");
CImg<unsigned char> WaitTop_yo = img_opacite(WaitTop_y);

CImg<unsigned char> WalkTop_1_y("Jardinier/yellow/WalkTop_1.pnm");
CImg<unsigned char> WalkTop_1_yo = img_opacite(WalkTop_1_y);

CImg<unsigned char> WalkTop_2_y("Jardinier/yellow/WalkTop_2.pnm");
CImg<unsigned char> WalkTop_2_yo = img_opacite(WalkTop_2_y);
////
CImg<unsigned char> WaitDown_y("Jardinier/yellow/WaitDown.pnm");
CImg<unsigned char> WaitDown_yo = img_opacite(WaitDown_y);

CImg<unsigned char> WalkDown_1_y("Jardinier/yellow/WalkDown_1.pnm");
CImg<unsigned char> WalkDown_1_yo = img_opacite(WalkDown_1_y);

CImg<unsigned char> WalkDown_2_y("Jardinier/yellow/WalkDown_2.pnm");
CImg<unsigned char> WalkDown_2_yo = img_opacite(WalkDown_2_y);
////
CImg<unsigned char> WaitLeft_y("Jardinier/yellow/WaitLeft.pnm");
CImg<unsigned char> WaitLeft_yo = img_opacite(WaitLeft_y);

CImg<unsigned char> WalkLeft_1_y("Jardinier/yellow/WalkLeft_1.pnm");
CImg<unsigned char> WalkLeft_1_yo = img_opacite(WalkLeft_1_y);

CImg<unsigned char> WalkLeft_2_y("Jardinier/yellow/WalkLeft_2.pnm");
CImg<unsigned char> WalkLeft_2_yo = img_opacite(WalkLeft_2_y);
////
CImg<unsigned char> WaitRight_y("Jardinier/yellow/WaitRight.pnm");
CImg<unsigned char> WaitRight_yo = img_opacite(WaitRight_y);

CImg<unsigned char> WalkRight_1_y("Jardinier/yellow/WalkRight_1.pnm");
CImg<unsigned char> WalkRight_1_yo = img_opacite(WalkRight_1_y);

CImg<unsigned char> WalkRight_2_y("Jardinier/yellow/WalkRight_2.pnm");
CImg<unsigned char> WalkRight_2_yo = img_opacite(WalkRight_2_y);

// Jardinier : rouge
CImg<unsigned char> WaitTop_r("Jardinier/red/WaitTop.pnm");
CImg<unsigned char> WaitTop_ro = img_opacite(WaitTop_r);

CImg<unsigned char> WalkTop_1_r("Jardinier/red/WalkTop_1.pnm");
CImg<unsigned char> WalkTop_1_ro = img_opacite(WalkTop_1_r);

CImg<unsigned char> WalkTop_2_r("Jardinier/red/WalkTop_2.pnm");
CImg<unsigned char> WalkTop_2_ro = img_opacite(WalkTop_2_r);
////
CImg<unsigned char> WaitDown_r("Jardinier/red/WaitDown.pnm");
CImg<unsigned char> WaitDown_ro = img_opacite(WaitDown_r);

CImg<unsigned char> WalkDown_1_r("Jardinier/red/WalkDown_1.pnm");
CImg<unsigned char> WalkDown_1_ro = img_opacite(WalkDown_1_r);

CImg<unsigned char> WalkDown_2_r("Jardinier/red/WalkDown_2.pnm");
CImg<unsigned char> WalkDown_2_ro = img_opacite(WalkDown_2_r);
////
CImg<unsigned char> WaitLeft_r("Jardinier/red/WaitLeft.pnm");
CImg<unsigned char> WaitLeft_ro = img_opacite(WaitLeft_r);

CImg<unsigned char> WalkLeft_1_r("Jardinier/red/WalkLeft_1.pnm");
CImg<unsigned char> WalkLeft_1_ro = img_opacite(WalkLeft_1_r);

CImg<unsigned char> WalkLeft_2_r("Jardinier/red/WalkLeft_2.pnm");
CImg<unsigned char> WalkLeft_2_ro = img_opacite(WalkLeft_2_r);
////
CImg<unsigned char> WaitRight_r("Jardinier/red/WaitRight.pnm");
CImg<unsigned char> WaitRight_ro = img_opacite(WaitRight_r);

CImg<unsigned char> WalkRight_1_r("Jardinier/red/WalkRight_1.pnm");
CImg<unsigned char> WalkRight_1_ro = img_opacite(WalkRight_1_r);

CImg<unsigned char> WalkRight_2_r("Jardinier/red/WalkRight_2.pnm");
CImg<unsigned char> WalkRight_2_ro = img_opacite(WalkRight_2_r);

//rose code 1
CImg<unsigned char> rose0("Plante/Fleur/rose/rose0.pnm");
CImg<unsigned char> rose0o = img_opacite(rose0);

CImg<unsigned char> rose1("Plante/Fleur/rose/rose1.pnm");
CImg<unsigned char> rose1o = img_opacite(rose1);

CImg<unsigned char> rose2("Plante/Fleur/rose/rose2.pnm");
CImg<unsigned char> rose2o = img_opacite(rose2);

CImg<unsigned char> rose3("Plante/Fleur/rose/rose3.pnm");
CImg<unsigned char> rose3o = img_opacite(rose3);

CImg<unsigned char> rose4("Plante/Fleur/rose/rose4.pnm");
CImg<unsigned char> rose4o = img_opacite(rose4);

CImg<unsigned char> rose5("Plante/Fleur/rose/rose5.pnm");
CImg<unsigned char> rose5o = img_opacite(rose5);

//pineapple code 2
CImg<unsigned char> pineapple0("Plante/Legume/pineapple/pineapple0.pnm");
CImg<unsigned char> pineapple0o = img_opacite(pineapple0);

CImg<unsigned char> pineapple1("Plante/Legume/pineapple/pineapple1.pnm");
CImg<unsigned char> pineapple1o = img_opacite(pineapple1);

CImg<unsigned char> pineapple2("Plante/Legume/pineapple/pineapple2.pnm");
CImg<unsigned char> pineapple2o = img_opacite(pineapple2);

CImg<unsigned char> pineapple3("Plante/Legume/pineapple/pineapple3.pnm");
CImg<unsigned char> pineapple3o = img_opacite(pineapple3);

CImg<unsigned char> pineapple4("Plante/Legume/pineapple/pineapple4.pnm");
CImg<unsigned char> pineapple4o = img_opacite(pineapple4);

CImg<unsigned char> pineapple5("Plante/Legume/pineapple/pineapple5.pnm");
CImg<unsigned char> pineapple5o = img_opacite(pineapple5);

//tulip code 3
CImg<unsigned char> tulip0("Plante/Fleur/tulip/tulip0.pnm");
CImg<unsigned char> tulip0o = img_opacite(tulip0);

CImg<unsigned char> tulip1("Plante/Fleur/tulip/tulip1.pnm");
CImg<unsigned char> tulip1o = img_opacite(tulip1);

CImg<unsigned char> tulip2("Plante/Fleur/tulip/tulip2.pnm");
CImg<unsigned char> tulip2o = img_opacite(tulip2);

CImg<unsigned char> tulip3("Plante/Fleur/tulip/tulip3.pnm");
CImg<unsigned char> tulip3o = img_opacite(tulip3);

CImg<unsigned char> tulip4("Plante/Fleur/tulip/tulip4.pnm");
CImg<unsigned char> tulip4o = img_opacite(tulip4);

CImg<unsigned char> tulip5("Plante/Fleur/tulip/tulip5.pnm");
CImg<unsigned char> tulip5o = img_opacite(tulip5);

//cucumber code 4
CImg<unsigned char> cucumber0("Plante/Legume/cucumber/cucumber0.pnm");
CImg<unsigned char> cucumber0o = img_opacite(cucumber0);

CImg<unsigned char> cucumber1("Plante/Legume/cucumber/cucumber1.pnm");
CImg<unsigned char> cucumber1o = img_opacite(cucumber1);

CImg<unsigned char> cucumber2("Plante/Legume/cucumber/cucumber2.pnm");
CImg<unsigned char> cucumber2o = img_opacite(cucumber2);

CImg<unsigned char> cucumber3("Plante/Legume/cucumber/cucumber3.pnm");
CImg<unsigned char> cucumber3o = img_opacite(cucumber3);

CImg<unsigned char> cucumber4("Plante/Legume/cucumber/cucumber4.pnm");
CImg<unsigned char> cucumber4o = img_opacite(cucumber4);

CImg<unsigned char> cucumber5("Plante/Legume/cucumber/cucumber5.pnm");
CImg<unsigned char> cucumber5o = img_opacite(cucumber5);

//melon code 5
CImg<unsigned char> melon0("Plante/Legume/melon/melon0.pnm");
CImg<unsigned char> melon0o = img_opacite(melon0);

CImg<unsigned char> melon1("Plante/Legume/melon/melon1.pnm");
CImg<unsigned char> melon1o = img_opacite(melon1);

CImg<unsigned char> melon2("Plante/Legume/melon/melon2.pnm");
CImg<unsigned char> melon2o = img_opacite(melon2);

CImg<unsigned char> melon3("Plante/Legume/melon/melon3.pnm");
CImg<unsigned char> melon3o = img_opacite(melon3);

CImg<unsigned char> melon4("Plante/Legume/melon/melon4.pnm");
CImg<unsigned char> melon4o = img_opacite(melon4);

CImg<unsigned char> melon5("Plante/Legume/melon/melon5.pnm");
CImg<unsigned char> melon5o = img_opacite(melon5);


//turnip code 6
CImg<unsigned char> turnip0("Plante/Legume/turnip/turnip0.pnm");
CImg<unsigned char> turnip0o = img_opacite(turnip0);

CImg<unsigned char> turnip1("Plante/Legume/turnip/turnip1.pnm");
CImg<unsigned char> turnip1o = img_opacite(turnip1);

CImg<unsigned char> turnip2("Plante/Legume/turnip/turnip2.pnm");
CImg<unsigned char> turnip2o = img_opacite(turnip2);

CImg<unsigned char> turnip3("Plante/Legume/turnip/turnip3.pnm");
CImg<unsigned char> turnip3o = img_opacite(turnip3);

CImg<unsigned char> turnip4("Plante/Legume/turnip/turnip4.pnm");
CImg<unsigned char> turnip4o = img_opacite(turnip4);

CImg<unsigned char> turnip5("Plante/Legume/turnip/turnip5.pnm");
CImg<unsigned char> turnip5o = img_opacite(turnip5);

//sunflower code 7
CImg<unsigned char> sunflower0("Plante/Legume/sunflower/sunflower0.pnm");
CImg<unsigned char> sunflower0o = img_opacite(sunflower0);

CImg<unsigned char> sunflower1("Plante/Legume/sunflower/sunflower1.pnm");
CImg<unsigned char> sunflower1o = img_opacite(sunflower1);

CImg<unsigned char> sunflower2("Plante/Legume/sunflower/sunflower2.pnm");
CImg<unsigned char> sunflower2o = img_opacite(sunflower2);

CImg<unsigned char> sunflower3("Plante/Legume/sunflower/sunflower3.pnm");
CImg<unsigned char> sunflower3o = img_opacite(sunflower3);

CImg<unsigned char> sunflower4("Plante/Legume/sunflower/sunflower4.pnm");
CImg<unsigned char> sunflower4o = img_opacite(sunflower4);

CImg<unsigned char> sunflower5("Plante/Legume/sunflower/sunflower5.pnm");
CImg<unsigned char> sunflower5o = img_opacite(sunflower5);

//strawberry code 8
CImg<unsigned char> strawberry0("Plante/Legume/strawberry/strawberry0.pnm");
CImg<unsigned char> strawberry0o = img_opacite(strawberry0);

CImg<unsigned char> strawberry1("Plante/Legume/strawberry/strawberry1.pnm");
CImg<unsigned char> strawberry1o = img_opacite(strawberry1);

CImg<unsigned char> strawberry2("Plante/Legume/strawberry/strawberry2.pnm");
CImg<unsigned char> strawberry2o = img_opacite(strawberry2);

CImg<unsigned char> strawberry3("Plante/Legume/strawberry/strawberry3.pnm");
CImg<unsigned char> strawberry3o = img_opacite(strawberry3);

CImg<unsigned char> strawberry4("Plante/Legume/strawberry/strawberry4.pnm");
CImg<unsigned char> strawberry4o = img_opacite(strawberry4);

CImg<unsigned char> strawberry5("Plante/Legume/strawberry/strawberry5.pnm");
CImg<unsigned char> strawberry5o = img_opacite(strawberry5);

//grapes code 9
CImg<unsigned char> grapes0("Plante/Legume/grapes/grapes0.pnm");
CImg<unsigned char> grapes0o = img_opacite(grapes0);

CImg<unsigned char> grapes1("Plante/Legume/grapes/grapes1.pnm");
CImg<unsigned char> grapes1o = img_opacite(grapes1);

CImg<unsigned char> grapes2("Plante/Legume/grapes/grapes2.pnm");
CImg<unsigned char> grapes2o = img_opacite(grapes2);

CImg<unsigned char> grapes3("Plante/Legume/grapes/grapes3.pnm");
CImg<unsigned char> grapes3o = img_opacite(grapes3);

CImg<unsigned char> grapes4("Plante/Legume/grapes/grapes4.pnm");
CImg<unsigned char> grapes4o = img_opacite(grapes4);

CImg<unsigned char> grapes5("Plante/Legume/grapes/grapes5.pnm");
CImg<unsigned char> grapes5o = img_opacite(grapes5);

//eggplant code 10
CImg<unsigned char> eggplant0("Plante/Legume/eggplant/eggplant0.pnm");
CImg<unsigned char> eggplant0o = img_opacite(eggplant0);

CImg<unsigned char> eggplant1("Plante/Legume/eggplant/eggplant1.pnm");
CImg<unsigned char> eggplant1o = img_opacite(eggplant1);

CImg<unsigned char> eggplant2("Plante/Legume/eggplant/eggplant2.pnm");
CImg<unsigned char> eggplant2o = img_opacite(eggplant2);

CImg<unsigned char> eggplant3("Plante/Legume/eggplant/eggplant3.pnm");
CImg<unsigned char> eggplant3o = img_opacite(eggplant3);

CImg<unsigned char> eggplant4("Plante/Legume/eggplant/eggplant4.pnm");
CImg<unsigned char> eggplant4o = img_opacite(eggplant4);

CImg<unsigned char> eggplant5("Plante/Legume/eggplant/eggplant5.pnm");
CImg<unsigned char> eggplant5o = img_opacite(eggplant5);

//corn code 11
CImg<unsigned char> corn0("Plante/Legume/corn/corn0.pnm");
CImg<unsigned char> corn0o = img_opacite(corn0);

CImg<unsigned char> corn1("Plante/Legume/corn/corn1.pnm");
CImg<unsigned char> corn1o = img_opacite(corn1);

CImg<unsigned char> corn2("Plante/Legume/corn/corn2.pnm");
CImg<unsigned char> corn2o = img_opacite(corn2);

CImg<unsigned char> corn3("Plante/Legume/corn/corn3.pnm");
CImg<unsigned char> corn3o = img_opacite(corn3);

CImg<unsigned char> corn4("Plante/Legume/corn/corn4.pnm");
CImg<unsigned char> corn4o = img_opacite(corn4);

CImg<unsigned char> corn5("Plante/Legume/corn/corn5.pnm");
CImg<unsigned char> corn5o = img_opacite(corn5);

//potato code 12
CImg<unsigned char> potato0("Plante/Legume/potato/potato0.pnm");
CImg<unsigned char> potato0o = img_opacite(potato0);

CImg<unsigned char> potato1("Plante/Legume/potato/potato1.pnm");
CImg<unsigned char> potato1o = img_opacite(potato1);

CImg<unsigned char> potato2("Plante/Legume/potato/potato2.pnm");
CImg<unsigned char> potato2o = img_opacite(potato2);

CImg<unsigned char> potato3("Plante/Legume/potato/potato3.pnm");
CImg<unsigned char> potato3o = img_opacite(potato3);

CImg<unsigned char> potato4("Plante/Legume/potato/potato4.pnm");
CImg<unsigned char> potato4o = img_opacite(potato4);

CImg<unsigned char> potato5("Plante/Legume/potato/potato5.pnm");
CImg<unsigned char> potato5o = img_opacite(potato5);

//avocado code 13
CImg<unsigned char> avocado0("Plante/Legume/avocado/avocado0.pnm");
CImg<unsigned char> avocado0o = img_opacite(avocado0);

CImg<unsigned char> avocado1("Plante/Legume/avocado/avocado1.pnm");
CImg<unsigned char> avocado1o = img_opacite(avocado1);

CImg<unsigned char> avocado2("Plante/Legume/avocado/avocado2.pnm");
CImg<unsigned char> avocado2o = img_opacite(avocado2);

CImg<unsigned char> avocado3("Plante/Legume/avocado/avocado3.pnm");
CImg<unsigned char> avocado3o = img_opacite(avocado3);

CImg<unsigned char> avocado4("Plante/Legume/avocado/avocado4.pnm");
CImg<unsigned char> avocado4o = img_opacite(avocado4);

CImg<unsigned char> avocado5("Plante/Legume/avocado/avocado5.pnm");
CImg<unsigned char> avocado5o = img_opacite(avocado5);

//orange code 14
CImg<unsigned char> orange0("Plante/Legume/orange/orange0.pnm");
CImg<unsigned char> orange0o = img_opacite(orange0);

CImg<unsigned char> orange1("Plante/Legume/orange/orange1.pnm");
CImg<unsigned char> orange1o = img_opacite(orange1);

CImg<unsigned char> orange2("Plante/Legume/orange/orange2.pnm");
CImg<unsigned char> orange2o = img_opacite(orange2);

CImg<unsigned char> orange3("Plante/Legume/orange/orange3.pnm");
CImg<unsigned char> orange3o = img_opacite(orange3);

CImg<unsigned char> orange4("Plante/Legume/orange/orange4.pnm");
CImg<unsigned char> orange4o = img_opacite(orange4);

CImg<unsigned char> orange5("Plante/Legume/orange/orange5.pnm");
CImg<unsigned char> orange5o = img_opacite(orange5);

//tomato code 15
CImg<unsigned char> tomato0("Plante/Legume/tomato/tomato0.pnm");
CImg<unsigned char> tomato0o = img_opacite(tomato0);

CImg<unsigned char> tomato1("Plante/Legume/tomato/tomato1.pnm");
CImg<unsigned char> tomato1o = img_opacite(tomato1);

CImg<unsigned char> tomato2("Plante/Legume/tomato/tomato2.pnm");
CImg<unsigned char> tomato2o = img_opacite(tomato2);

CImg<unsigned char> tomato3("Plante/Legume/tomato/tomato3.pnm");
CImg<unsigned char> tomato3o = img_opacite(tomato3);

CImg<unsigned char> tomato4("Plante/Legume/tomato/tomato4.pnm");
CImg<unsigned char> tomato4o = img_opacite(tomato4);

CImg<unsigned char> tomato5("Plante/Legume/tomato/tomato5.pnm");
CImg<unsigned char> tomato5o = img_opacite(tomato5);

//lemon code 16
CImg<unsigned char> lemon0("Plante/Legume/lemon/lemon0.pnm");
CImg<unsigned char> lemon0o = img_opacite(lemon0);

CImg<unsigned char> lemon1("Plante/Legume/lemon/lemon1.pnm");
CImg<unsigned char> lemon1o = img_opacite(lemon1);

CImg<unsigned char> lemon2("Plante/Legume/lemon/lemon2.pnm");
CImg<unsigned char> lemon2o = img_opacite(lemon2);

CImg<unsigned char> lemon3("Plante/Legume/lemon/lemon3.pnm");
CImg<unsigned char> lemon3o = img_opacite(lemon3);

CImg<unsigned char> lemon4("Plante/Legume/lemon/lemon4.pnm");
CImg<unsigned char> lemon4o = img_opacite(lemon4);

CImg<unsigned char> lemon5("Plante/Legume/lemon/lemon5.pnm");
CImg<unsigned char> lemon5o = img_opacite(lemon5);

//les numeros
CImg<unsigned char> zero("Numero/0.pnm");
CImg<unsigned char> zeroo = img_opacite(zero);

CImg<unsigned char> un("Numero/1.pnm");
CImg<unsigned char> uno = img_opacite(un);

CImg<unsigned char> deux("Numero/2.pnm");
CImg<unsigned char> deuxo = img_opacite(deux);

CImg<unsigned char> trois("Numero/3.pnm");
CImg<unsigned char> troiso = img_opacite(trois);

CImg<unsigned char> quatre("Numero/4.pnm");
CImg<unsigned char> quatreo = img_opacite(quatre);

CImg<unsigned char> cinq("Numero/5.pnm");
CImg<unsigned char> cinqo = img_opacite(cinq);

CImg<unsigned char> six("Numero/6.pnm");
CImg<unsigned char> sixo = img_opacite(six);

CImg<unsigned char> sept("Numero/7.pnm");
CImg<unsigned char> septo = img_opacite(sept);

CImg<unsigned char> huit("Numero/8.pnm");
CImg<unsigned char> huito = img_opacite(huit);

CImg<unsigned char> neuf("Numero/9.pnm");
CImg<unsigned char> neufo = img_opacite(neuf);



CImg<unsigned char> NumToImg(char c)
{
    switch(c)
    {
    case '0':
        return zero;
    case '1':
        return un;
    case '2':
        return deux;
    case '3':
        return trois;
    case '4':
        return quatre;
    case '5':
        return cinq;
    case '6':
        return six;
    case '7':
        return sept;
    case '8':
        return huit;
    case '9':
        return neuf;
    }
}

CImg<unsigned char> NumToImgo(char c)
{
    switch(c)
    {
    case '0':
        return zeroo;
    case '1':
        return uno;
    case '2':
        return deuxo;
    case '3':
        return troiso;
    case '4':
        return quatreo;
    case '5':
        return cinqo;
    case '6':
        return sixo;
    case '7':
        return septo;
    case '8':
        return huito;
    case '9':
        return neufo;
    }

}

