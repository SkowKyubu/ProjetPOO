#include <iostream>
class Vehicule{
public:
    int vitesse;
};
